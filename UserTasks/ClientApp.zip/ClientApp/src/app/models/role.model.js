"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Role = /** @class */ (function () {
    function Role(name, permissions) {
        this.name = name;
        this.permissions = permissions;
    }
    return Role;
}());
exports.Role = Role;
//# sourceMappingURL=role.model.js.map