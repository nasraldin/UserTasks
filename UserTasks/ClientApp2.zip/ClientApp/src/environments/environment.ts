
export const environment = {
  production: false,
  baseUrl: null, 
  loginUrl: "/Login"
};
