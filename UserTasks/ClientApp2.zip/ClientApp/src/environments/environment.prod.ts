
export const environment = {
    production: true,
    baseUrl: null, 
    loginUrl: "/Login"
};
