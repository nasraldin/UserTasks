"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserLogin = /** @class */ (function () {
    function UserLogin(email, password) {
        this.email = email;
        this.password = password;
    }
    return UserLogin;
}());
exports.UserLogin = UserLogin;
//# sourceMappingURL=user-login.model.js.map