"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Role = /** @class */ (function () {
    function Role(name, description, permissions) {
        this.name = name;
        this.description = description;
        this.permissions = permissions;
    }
    return Role;
}());
exports.Role = Role;
//# sourceMappingURL=role.model.js.map